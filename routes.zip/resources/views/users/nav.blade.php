<div class="user-nav  d-none d-md-block mb-3 text-white " id="navuser">
    <a href="/dashboard" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-home"> </i>
            Dashboard
        </div>
    </a>
    <a href="/deposit" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-light fa-sack-dollar"> </i>
            Deposit
        </div>
    </a>

    <a href="/convert" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-money-check-dollar"></i>
            Buy Prime Coin
        </div>
    </a>

    <a href="/transfer" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-money-bill-wave-alt"> </i>
            Transfer
        </div>
    </a>

    <a href="#" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-money-bill-wave-alt"> </i>
            Trade
        </div>
    </a>


    <a href="#" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-light fa-wallet"> </i>
            Withdraw
        </div>
    </a>


    <hr>

    <a href="#" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-user-cog"> </i>
            Wallet Settings
        </div>
    </a>

    <a href="/logout" class="text-white">
        <div class="nav-item p-1 mb-2 hover">
            <i class="fa fa-power-off"> </i>
            Log Out
        </div>
    </a>


</div>
